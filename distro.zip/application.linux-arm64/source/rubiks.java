import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import peasy.*; 
import peasy.org.apache.commons.math.*; 
import peasy.org.apache.commons.math.geometry.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class rubiks extends PApplet {

/**
  Controls :
    C : reset cube
    M : reset and mix cube
    SPACE : reset, mix and solve cube
    [Displayed letter] : select matching face
    UP or RIGHT : Rotate selected face clockwise
    DOWN or LEFT : Rotate selected face counter-clockwise
**/






private static final int MOVE_FRAMES = 20;  // How many animation frames for each move
private static final float SCALE = 16f;     // Drawing scale (faces are drawn with size 1, border width .2)
private static final int MIX_MOVES = 50;    // How many moves to mix cube automatically


// Sketch state
private PGraphics canvas3d;
private boolean caminit = false;
private PeasyCam cam;
private Cube cube;
private Move currentMove = null;
private Move nextMove = null;
private Face selectedFace = null;

private Move[] solveMoves;
private int solveIndex = -1;


// Before any render
public void setup() {
  //size(800, 600, P3D);
  
  canvas3d = createGraphics(width, height, P3D);
  cam = new PeasyCam(this, canvas3d, 150 - 1);
  cam.setRotations(HALF_PI / 6, HALF_PI / 6, - HALF_PI / 30);
  cube = new Cube();
}

// On each rendering frame
public void draw() {
  
  if (!caminit) {
    cam.setDistance(cam.getDistance() + 1, 1);
    caminit = true;
  }
  
  //If we are solving, chain solving moves
  if (solveIndex >= 0 && solveIndex < solveMoves.length) {
      if (nextMove == null) {
         nextMove = solveMoves[solveIndex++]; 
      }
  }
  
  //Apply next move after current move is done. This allows recording one keyboard input before current animation is complete
  if (currentMove != null) {
    if (currentMove.isDone()) {
      cube.applyMoveIfDone();
      currentMove = null;
      if (nextMove != null) {
        currentMove = nextMove;
        nextMove = null;
        cube.startMove(currentMove);
      }
    } else {
      currentMove.step();
    }
  } else if (nextMove != null) {
    currentMove = nextMove;
    nextMove = null;
    cube.startMove(currentMove);
  }
  
  //Do actual drawing
  canvas3d.beginDraw();
  canvas3d.background(55);
  canvas3d.scale(SCALE);
  canvas3d.rectMode(CENTER);
  cube.show(canvas3d); // <- Cube drawn
  /* now we'll draw the text marker for each face */
  canvas3d.scale(.05f);
  canvas3d.textSize(30);
  canvas3d.textAlign(CENTER, CENTER);
  textFace(Face.UP, 0, -60, 0);
  textFace(Face.DOWN, 0, 60, 0);
  textFace(Face.LEFT, -60, 0, 0);
  textFace(Face.RIGHT, 60, 0, 0);
  textFace(Face.FRONT, -50, -50, 60);
  textFace(Face.BACK, 50, 50, -60);
  canvas3d.endDraw();
  
  //Draw 2D
  hint(DISABLE_DEPTH_TEST);
  noLights();
  image(canvas3d, 0, 0);
  textMode(MODEL);
  fill(255, 0, 255);
  textSize(height / 30f);
  textAlign(LEFT, TOP);
  text("FrameRate: " + frameRate + "fps", 0, 0);
  fill(128);
  float tsz = height / 40f;
  textSize(tsz);
  textAlign(RIGHT, BOTTOM);
  text("[C] Reset, [M] Mix, [SPACE] Mix & solve, [Face letter] Select face, [↑/→] Rotate face \u21bb, [↓/←] Rotate face \u21ba", width, height);
  text("Mouse drag to control view, scroll to zoom, middle button to shift", width, height - tsz);
}

// Key pressed event: manage controls
public void keyPressed() {
  //Special commands (reset-mix, reset, reset-mix-solve)
  if (solveIndex < 0 || solveIndex >= solveMoves.length) {
    if (currentMove == null) {
       switch (key) {
          case 'm':
          case 'M':
            mix();
            return;
          case 'c':
          case 'C':
            cube.reset();
            return;
          case ' ':
            mix();
            fakeSolve();
            return;
       }
    }
    
    //Select face
    Face f = Face.forLetter(key);
    if (f != null) {
      selectedFace = f;
    }
    
    //Rotate selected
    Direction dir = null;
    switch (keyCode) {
    case UP:
    case RIGHT:
      dir = Direction.CLOCKWISE;
      break;
    case DOWN:
    case LEFT:
      dir = Direction.COUNTER_CLOCKWISE;
      break;
    }
    //Apply move if direction chosen
    if (dir != null && selectedFace != null) {
      nextMove = new Move(selectedFace, dir);
    }
    
  }
}


// Draw text for a face at given position (using first letter in face name)
private void textFace(Face face, float x, float y, float z) {
  canvas3d.fill(face == selectedFace ? color(255, 0, 255) : color(255));
  canvas3d.text(face.getLetter(), x, y, z);
}

// Mix the Rubik's cube (make a sequence of MIX_MOVES moves for fake-solving and apply it backwards)
private void mix() {

  cube.reset();
  
  solveMoves = new Move[MIX_MOVES];
  for (int i = 0; i < solveMoves.length; i++) {
    boolean notSet = true;
    Face face = null;
    Direction dir = null;
    while (notSet) { // Avoid back and forth rotations, and prevent repeating moves more than twice, which makes no sense
      face = Face.values()[PApplet.parseInt(random(6))];
      dir = Direction.values()[PApplet.parseInt(random(2))];
      if (i < 1) {
        notSet = false;
      } else {
         Move pm = solveMoves[i - 1];
         if (pm.getFace() != face) {
            notSet = false; 
         } else if (pm.getDirection() != dir) {
            continue; 
         }
         if (i > 1) {
           pm = solveMoves[i - 2];
           if (pm.getFace() != face) {
              notSet = false; 
           }
         }
      }
    }
    solveMoves[i] = new Move(face, dir);
  }
  
  for (int i = solveMoves.length - 1; i >= 0; i--) {
    Move m = solveMoves[i].invert();
    cube.rotateFace(m.getFace(), m.getDirection());
  }
}

//Start fake solving (playing recorded solving moves)
private void fakeSolve() {
  if (solveMoves.length > 0 && (solveIndex < 0 || solveIndex >= solveMoves.length)) {
   solveIndex = 0; //Will trigger solving in draw()
  }
}
private class Cube {

  private Cubie[] qbs; //All cubies (small cube elements) in this Rubik's cube

  public Cube() {
    qbs  = new Cubie[26];
    int index = 0;
    for (int x = -1; x < 2; x++) {
      for (int y = -1; y < 2; y++) {
        for (int z = -1; z < 2; z++) {
          if (x == 0 && y == 0 && z == 0) //No Cubie in center
            continue;
          qbs[index++] = new Cubie(x, y, z);
        }
      }
    }
  }

  //Draw cube
  public void show(PGraphics g) {
    for (Cubie qb : qbs)
      qb.show(g);
  }

  //Do a move with animation (rotate a given face in a given direction)
  public void startMove(Move move) {
    Cubie[] faceElems = selectFace(move.getFace());
    for (Cubie qb : faceElems)
      qb.setCurrentMove(move);
  }

  //Apply current move as soon as animation is complete
  public void applyMoveIfDone() {
    for (Cubie qb : qbs)
      qb.applyMoveIfDone();
  }

  //Immediately rotate a given face in the given direction with no animation
  public void rotateFace(Face face, Direction dir) {
    Cubie[] faceElems = selectFace(face);
    //Rotation angle will be PI/2 on the same axis as the face's center, negated if direction is counter-clockwise
    PVector angles = face.getCenter().copy().setMag(HALF_PI).mult(dir.getDir());
    for (Cubie qb : faceElems)
      qb.rotateAbout(face.getCenter(), angles);
  }

  //Restore initial state
  public void reset() {
    for (Cubie qb : qbs) {
      qb.reset();
    }
  }

  //Select all Cubies making up a Cube Face
  //i.e. based on each Cubie's current transformation, get the 9 ones that are shifted in the same direction as Face center from Cube center (0, 0, 0)
  private Cubie[] selectFace(Face face) {
    Cubie[] faceElems = new Cubie[9];
    PVector fc = face.getCenter();
    int index = 0;
    PVector pos = new PVector();
    //println("---- in face (", fc.x, fc.y, fc.z, ") ------");
    for (Cubie qb : qbs) {
      qb.putCurrentPos(pos);
      pos.x = round(pos.x * 100); // Consider only 2 decimals to compensate for float approximations around 0
      pos.y = round(pos.y * 100);
      pos.z = round(pos.z * 100);
      if (
        fc.x > 0 && pos.x > 0 ||
        fc.x < 0 && pos.x < 0 ||
        fc.y > 0 && pos.y > 0 ||
        fc.y < 0 && pos.y < 0 ||
        fc.z > 0 && pos.z > 0 ||
        fc.z < 0 && pos.z < 0
        ) {
        //println(index, ": Put Cubie (", qb.pos.x, qb.pos.y, qb.pos.z, ") @ [", pos.x, pos.y, pos.z, "]");
        faceElems[index++] = qb;
      }
    }
    return faceElems;
  }
}
private class Cubie {

  private final PVector initPos; //Initial position
  private final PMatrix3D transforms; //Transformation matrix from cube center (current state)
  private final CubieFace[] faces;

  private Move currentMove = null; //Move being currently applied (animation, then result)

  public Cubie(int x, int y, int z) {
    this.initPos = new PVector(x, y, z); 
    this.transforms = new PMatrix3D(); 
    this.transforms.translate(x, y, z);
    //Create all faces according to Face Enum
    this.faces = new CubieFace[6];
    Face[] allFaces = Face.values();
    for (int index = 0; index < allFaces.length; index++) {
      Face face = allFaces[index];
      PVector facePos = face.getCenter().copy().div(2);
      //Decide color depending on relative position (which is also a normal vector)
      int col = color(0);
      float colorize = x * facePos.x + y * facePos.y + z * facePos.z;
      if (colorize > 0) {
        switch (face) {
          case RIGHT:
            col = color(255, 0, 0);   //red
            break;
          case LEFT:
            col = color(255, 128, 0); //orange
            break;
          case DOWN:
            col = color(255, 255, 0); //yellow
            break;
          case UP:
            col = color(255);         //white
            break;
          case FRONT:
            col = color(0, 255, 0);   //green
            break;
          case BACK:
            col = color(0, 0, 255);   //blue
            break;
        }
      }
      faces[index] = new CubieFace(col, facePos);
    }
  }

  public void setCurrentMove(Move move) {
    this.currentMove = move;
  }

  //Copy current position according to transforms into result vector
  public void putCurrentPos(PVector result) {
    //transformation matix contains current position in its last column
    result.set(transforms.m03, transforms.m13, transforms.m23);
  }

  //Immediately apply a rotation about a center with xyz angles given in a vector (move with no animation)
  public void rotateAbout(PVector center, PVector axisAngle) {
    PMatrix3D transf = new PMatrix3D();
    rotateMatrixAround(transf, center, axisAngle);
    transforms.preApply(transf);
  }
  
  //Restore initial position (clear transforms and move)
  public void reset() {
    transforms.reset();
    this.transforms.translate(this.initPos.x, this.initPos.y, this.initPos.z);
    currentMove = null;
  }
  
  //Apply current move as soon as animation is complete
  public void applyMoveIfDone() {
    if (currentMove != null && currentMove.isDone()) { // Apply current move as soon as animation is complete
      transforms.set(currentMove.combineTransform(transforms));
      currentMove = null;
    }
  }

  //Draw all faces in the right position and orientation.
  public void show(PGraphics g) {
    //Combine animation with applied transformations
    PMatrix3D transf = transforms;
    if (currentMove != null) {
      transf = currentMove.combineTransform(transforms);
    }

    g.pushMatrix();
    g.applyMatrix(transf); // Applies Cubie transformation to drawing plane.
    for (CubieFace face : faces) //Draw each face
      face.show(g);
    g.popMatrix();
  }
}
private class CubieFace {

  private int col;            //Face color
  private PMatrix3D relTransf;  //Transform (translation and rotation) from parent cubie

  // relpos is CubieFace center position relative to its parent cubie. It's also the face's normal vector
  // CubieFace transform is shifted by relPos and rotated according to it's normal
  // CubieFace color is col
  public CubieFace(int col, PVector relpos) {
    this.col = col;
    this.relTransf = new PMatrix3D();
    this.relTransf.translate(relpos.x, relpos.y, relpos.z);
    if (relpos.y != 0)
      this.relTransf.rotateX(HALF_PI);
    if (relpos.x != 0)
      this.relTransf.rotateY(HALF_PI);
  }

  //draw face as as square (side 1, border .2) of color col, according to its relative transformation
  public void show(PGraphics g) {
    g.pushMatrix();
    g.applyMatrix(relTransf); //Apply relative transformation.
    g.fill(col);
    g.stroke(0);
    g.strokeWeight(.2f);
    g.square(0, 0, 1);
    g.popMatrix();
  }
}
//Defines a Face by it's center, which is also its normal vector
private enum Face {
  UP(new PVector(0, -1, 0)),
  DOWN(new PVector(0, 1, 0)),
  LEFT(new PVector(-1, 0, 0)),
  RIGHT(new PVector(1, 0, 0)),
  FRONT(new PVector(0, 0, 1)),
  BACK(new PVector(0, 0, -1)),
  ;
  
  PVector center;
  
  private Face(PVector center) {
     this.center = center; 
  }
  
  //Get Face center
  public PVector getCenter() {
    return center;
  }
  
  //Get letter representing this Face
  public String getLetter() {
    return name().substring(0, 1);
  }
  
  //Given a letter, get a Face represented by it
  public static Face forLetter(char letter) {
    for (Face f : Face.values()) {
       if (f.name().charAt(0) == letter || f.name().toLowerCase().charAt(0) == letter)
         return f;
    }
    return null;
  }
  
}

//Defines a rotation direction with a signed value (clockwise = 1, counter-clockwise = -1)
private enum Direction {
  
  CLOCKWISE(1),
  COUNTER_CLOCKWISE(-1),
  ;
  
  int dir;
  
  private Direction(int dir) {
     this.dir = dir; 
  }
  
  //get rotation direction
  public int getDir() {
    return dir;
  }
    
}
//Apply a rotation about center by xyz angles given in axisAngles to an already existing transformation matrix
public static void rotateMatrixAround(PMatrix3D transf, PVector center, PVector axisAngle) {
  //translate to rotation center
  transf.translate(center.x, center.y, center.z);
  //rotate about all 3 axes as defined by axisAngles
  if (axisAngle.x != 0)
    transf.rotateX(axisAngle.x);
  if (axisAngle.y != 0)
    transf.rotateY(axisAngle.y);
  if (axisAngle.z != 0)
    transf.rotateZ(axisAngle.z);
  //translate back
  PVector reverse = center.copy().mult(-1);
  transf.translate(reverse.x, reverse.y, reverse.z);
}
//Represents a move being applied to a Rubik's cube face. Useful for animation
private class Move implements Cloneable {
  
  private final Face face;           //Face to move
  private final Direction direction; //Rotation direction
  
  //Animation state
  private int iteration = 0;
  private float angle;
  private final float target;
  private boolean done = false; 
  
  public Move(Face face, Direction direction) {
    this.face = face;
    this.direction = direction;
    target = direction.getDir() * HALF_PI;
  }
  
  /* Getters */
  
  public Face getFace() {
     return face; 
  }
  
  public Direction getDirection() {
    return direction;
  }
  
  public boolean isDone() {
     return done; 
  }
  
  /* End getters */
  
  
  //Advance animation by 1 step. Limit to target angle, mak done if angle exceeded
  public void step() {
    float remain = target - angle;
    float remainsteps = MOVE_FRAMES - iteration++;
    angle += remain / remainsteps;
    if (abs(angle) >= abs(target)) {
      angle = target;
      done = true;
    }
  }
  
  //Combine a base transformation matrix with move being animated. Return a new matrix containing the result
  public PMatrix3D combineTransform(PMatrix3D baseTransform) {
    PMatrix3D transf = new PMatrix3D();
    PVector fc = face.getCenter();
    PVector pos = fc.copy().setMag(1).mult(angle);
    rotateMatrixAround(transf, fc, pos);
    transf.apply(baseTransform);
    return transf;
  }
  
  //Duplicate move (parameters, not state)
  @Override
  public Move clone() {
    return new Move(face, direction);
  }

  //Duplicate move with reversed direction
  public Move invert() {
    return new Move(face, direction == Direction.CLOCKWISE ? Direction.COUNTER_CLOCKWISE : Direction.CLOCKWISE);
  }
  
}
  public void settings() {  fullScreen(P3D); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "rubiks" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
